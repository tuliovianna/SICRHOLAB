/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import dao.UsuarioJpaController;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import modelo.Usuario;

/**
 *
 * @author Túlio
 */
@ManagedBean
@RequestScoped
public class UsuarioMB {

    EntityManagerFactory factory = Persistence.createEntityManagerFactory("SICHROLABPU");
    
    UsuarioJpaController daoUsuario = new UsuarioJpaController(factory);
    
    private Usuario usuario = new Usuario();
    
    
    public UsuarioMB() {
    }
    
    public void inserirUsuario(){
        getUsuario().setId(null);
        daoUsuario.create(usuario);
    }

    public Usuario getUsuario() {
        return usuario;
    }
    
    
}
